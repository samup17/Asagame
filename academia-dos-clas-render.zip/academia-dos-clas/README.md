# Academia dos Clãs

RPG educacional multiplayer, leve e mobile-first, criado para um projeto escolar.

## O que já funciona

- Login por código de acesso, sem senha em texto puro.
- Papéis STUDENT, TEACHER e ADMIN.
- SQLite com criação automática do banco e seed inicial.
- Dashboard, perfil, progresso por matéria, clãs, ranking, inventário, loja, frutas e missões.
- Sistema de perguntas com múltipla escolha, verdadeiro/falso, número e texto.
- Histórico de respostas e anti-repetição recente.
- XP, níveis, moedas e pontos de clã.
- Batalha PvP em tempo real via Socket.IO, com perguntas validadas no servidor.
- Ataque, crítico, HP e recompensas de batalha.
- Painel de professor para criar/excluir perguntas e ver estatísticas.
- Painel de administrador com visão geral de usuários e turmas.
- Dados demo para apresentação.
- Interface responsiva para Android, tablet e desktop.
- Sem imagens, músicas ou personagens de franquias protegidas.

## Requisitos

- Node.js 20 ou superior.
- npm.

## Instalação

1. Instale Node.js pelo site oficial.
2. Extraia o ZIP.
3. Abra um terminal dentro da pasta.
4. Execute:

```bash
npm install
npm start
```

5. Acesse `http://localhost:3000`.

Para desenvolvimento:

```bash
npm run dev
```

O banco é criado automaticamente em `database/academia.db`.

## Contas demo

- Aluno Demo 1: `#701-4582`
- Aluno Demo 2: `#702-7714`
- Professor Demo: `PROF-0001`
- Administrador Demo: `ADMIN-0001`

Os códigos são apenas para demonstração local. Em produção, troque-os.

## Estrutura

- `client/`: interface, CSS e JavaScript do navegador.
- `server/`: API REST, autenticação, economia, perguntas e Socket.IO.
- `database/schema.sql`: estrutura do banco.
- `database/academia.db`: criado no primeiro início.
- `start.bat`: inicialização rápida no Windows.

## Banco de dados

O projeto usa SQLite por simplicidade. A camada de acesso está concentrada em `server/database.js` e nas rotinas do servidor. Para migrar para PostgreSQL, substitua a implementação de persistência mantendo os contratos das rotas.

## Multiplayer

Abra o sistema em duas janelas/dispositivos na mesma rede. Faça login com os dois alunos demo. Em **Batalha**, um jogador deverá aparecer como online. O primeiro envia o desafio; o segundo aceita.

Para testar em outro celular na mesma rede local:

1. Descubra o IP do computador, por exemplo `192.168.0.10`.
2. Inicie com `npm start`.
3. No celular, abra `http://192.168.0.10:3000`.
4. Libere a porta 3000 no firewall se necessário.

## Segurança

O servidor é a autoridade para respostas, XP, moedas, dano, vitórias e compras. O cliente não pode simplesmente pedir uma quantidade arbitrária de moedas.

Boas práticas para produção:

- defina `SESSION_SECRET` em `.env`;
- use HTTPS;
- troque códigos demo;
- adicione rate limiting;
- faça backups;
- configure logs;
- adicione CSRF para operações sensíveis se o sistema for publicado;
- considere PostgreSQL para grande escala;
- adicione políticas de retenção e controles adequados à legislação e às regras da escola.

## Professor

O painel permite:

- criar perguntas;
- definir matéria;
- série;
- assunto;
- dificuldade;
- tipo;
- alternativas;
- resposta;
- explicação;
- XP e moedas;
- excluir perguntas;
- visualizar desempenho por matéria.

## Administração

A API administrativa já possui operações para usuários, turmas e clãs. A interface pode ser ampliada sem mudar o núcleo do banco.

## Expansão futura

A arquitetura foi separada para facilitar:

- gerador de perguntas por IA;
- centenas de conteúdos;
- PostgreSQL;
- eventos de clã;
- matchmaking;
- temporadas;
- torneios;
- mais equipamentos;
- sistema de conquistas;
- relatórios do professor;
- importação CSV;
- autenticação institucional;
- PWA/instalação no celular.

## Observação sobre a Fruta da Capivara

Ela é lendária e cara dentro da economia fictícia, mas não foi projetada para exigir horas intermináveis de jogo. Eventos e recompensas especiais podem ser usados para mantê-la difícil sem estimular excesso de tempo de tela.

## Licença

Projeto escolar demonstrativo. Você pode adaptar o código para seu projeto.


## Deploy no Render (recomendado para o teste)

Publique este projeto como **Web Service**, não como Static Site, porque ele executa Express, sessões, SQLite e Socket.IO. O Render oferece Web Services Node/Express e suporta conexões WebSocket.

1. Coloque a pasta em um repositório GitHub.
2. No Render, escolha **New → Web Service** e conecte o repositório.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Plan: **Free** para teste.
6. O `render.yaml` já define `NODE_ENV`, `SESSION_SECRET`, `DATABASE_URL` e o health check.
7. Teste `https://SEU-ENDERECO.onrender.com/api/health`.
8. Abra o site em dois navegadores/dispositivos, crie duas contas e teste **Batalha**.

### Limitação do Render Free

O serviço gratuito pode suspender após 15 minutos sem tráfego e o filesystem local é efêmero. Por isso, o SQLite local serve para **testes**, mas os dados podem ser perdidos após reinício/suspensão/redeploy. Para uma versão escolar persistente, migre a persistência para PostgreSQL.

### Multiplayer

O projeto usa Socket.IO sobre o mesmo Web Service. Não abra como Static Site. O indicador de conexão e a tela de Batalha ajudam a verificar a conexão em tempo real.
