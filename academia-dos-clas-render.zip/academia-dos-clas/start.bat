@echo off
title Academia dos Clas
echo ==========================================
echo       ACADEMIA DOS CLAS - INICIANDO
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao encontrado. Instale Node.js 20 ou superior.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando dependencias...
  call npm install
)
echo Abrindo servidor...
call npm start
pause
