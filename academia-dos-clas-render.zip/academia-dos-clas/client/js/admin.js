import {api} from "./auth.js";
export async function adminOverview(){return api("/api/admin/overview")}
export async function teacherStats(){return api("/api/teacher/stats")}
