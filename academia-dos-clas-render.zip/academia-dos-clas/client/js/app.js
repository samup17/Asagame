import {api,login,logout,me} from "./auth.js";
import {loadQuestion,answerQuestion} from "./questions.js";
import {shop,buy,inventory} from "./inventory.js";
import {clan} from "./clan.js";
import {connect,getSocket} from "./multiplayer.js";
import {battleView} from "./battle.js";
import {adminOverview,teacherStats} from "./admin.js";

const app=document.querySelector("#app");
let user=null, bootstrap=null;

const routes={
 "/login":renderLogin,"/dashboard":renderDashboard,"/profile":renderProfile,"/clan":renderClan,
 "/battle":renderBattle,"/inventory":renderInventory,"/shop":renderShop,"/fruits":renderFruits,
 "/ranking":renderRanking,"/subjects":renderSubjects,"/missions":renderMissions,"/teacher":renderTeacher,"/admin":renderAdmin
};

function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(m){const t=document.querySelector("#toast");t.textContent=m;t.classList.remove("hidden");setTimeout(()=>t.classList.add("hidden"),2600);}
window.toast=toast;

async function init(){
  user=await me();
  if(!user){return renderLogin();}
  bootstrap=await api("/api/bootstrap");
  connect();
  render();
}
function render(){
  const path=location.pathname;
  const fn=routes[path]||renderDashboard;
  fn();
}
window.addEventListener("popstate",render);
function go(path){history.pushState({}, "", path);render();}

function nav(){
  const items=[
    ["/dashboard","🏠","Início"],["/subjects","📚","Estudar"],["/battle","⚔️","Batalha"],
    ["/inventory","🎒","Inventário"],["/shop","🛒","Loja"],["/clan","🏰","Clã"],["/ranking","🏆","Ranking"],["/fruits","🍈","Frutas"],["/missions","🎯","Missões"]
  ];
  if(user.role!=="STUDENT") items.push(["/teacher","🧑‍🏫","Professor"]);
  if(user.role==="ADMIN") items.push(["/admin","🛠️","Admin"]);
  return `<aside class="sidebar"><div class="brand"><div class="brand-mark">✦</div> Academia</div><nav class="nav">
    ${items.map(x=>`<button class="${location.pathname===x[0]?"active":""}" onclick="go('${x[0]}')">${x[1]}<br>${x[2]}</button>`).join("")}
    <button onclick="logout()">🚪<br>Sair</button></nav></aside>`;
}
function layout(title,content){
  app.innerHTML=`<div class="shell">${nav()}<main class="main"><div class="topbar"><div><h1>${title}</h1><div class="muted">${esc(user.nickname)} · ${user.clan?.name||"Sem clã"}</div></div><div class="top-actions"><span class="pill">🪙 ${user.coins}</span><span class="pill">LV ${user.level}</span></div></div>${content}</main></div>`;
}
window.go=go;window.logout=logout;

function renderLogin(){
  app.innerHTML=`<main class="login"><section class="card login-card pop"><div class="logo-big float">✦</div><h1>Academia dos Clãs</h1><p class="muted">Entre, crie sua conta ou participe como professor.</p>
  <div class="actions"><button class="btn" id="showStudent">Criar conta</button><button class="btn secondary" id="showLogin">Entrar</button><button class="btn gold" id="showTeacher">Sou professor</button></div>
  <div id="authBox" style="margin-top:16px"></div>
  <div class="card" style="margin-top:14px"><strong>🎓 Professor demo</strong><p class="muted">Código de convite para criar conta de professor: <b>PROF-ACADEMIA-2026</b></p><strong>Contas antigas de demonstração</strong><p class="muted">Aluno: <b>#701-4582</b> · Professor: <b>PROF-0001</b> · Admin: <b>ADMIN-0001</b></p></div></section></main>`;
  const box=document.querySelector("#authBox");
  const loginForm=()=>{box.innerHTML=`<form id="loginForm" class="form"><div class="field"><label for="code">Código de acesso</label><input id="code" required placeholder="ACD-XXXXXX-XXXX"></div><button class="btn">Entrar na Academia</button></form>`;document.querySelector("#loginForm").onsubmit=async e=>{e.preventDefault();try{await login(document.querySelector("#code").value);location.href="/dashboard"}catch(err){toast(err.message)}}};
  const studentForm=()=>{box.innerHTML=`<form id="studentForm" class="form"><div class="field"><label>Nome de exibição</label><input name="name" maxlength="60" placeholder="Opcional"></div><div class="field"><label>Apelido</label><input name="nickname" maxlength="24" required placeholder="Seu nome no jogo"></div><div class="field"><label>Turma (opcional)</label><select name="class_id"><option value="">Sem turma por enquanto</option></select></div><button class="btn">Criar minha conta</button><p class="muted">No final, o sistema entrega seu código de acesso. Guarde-o.</p></form>`;fetch("/api/public/classes").then(r=>r.json()).then(cs=>{const sel=document.querySelector('[name="class_id"]');cs.forEach(c=>{const o=document.createElement("option");o.value=c.id;o.textContent=`${c.name} · ${c.clan_name}`;sel.appendChild(o)})});document.querySelector("#studentForm").onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);try{const r=await api("/api/auth/register",{method:"POST",body:JSON.stringify(Object.fromEntries(f))});box.innerHTML=`<div class="hero"><h2>🎉 Conta criada!</h2><p>Seu código de acesso é:</p><h1 style="letter-spacing:2px">${esc(r.access_code)}</h1><p class="muted">Salve esse código. Ele será usado para entrar novamente.</p><button class="btn" id="continueBtn">Entrar na Academia</button></div>`;document.querySelector("#continueBtn").onclick=()=>location.href="/dashboard";}catch(err){toast(err.message)}}};
  const teacherForm=()=>{box.innerHTML=`<form id="teacherForm" class="form"><div class="field"><label>Nome</label><input name="name" required maxlength="60"></div><div class="field"><label>Apelido profissional</label><input name="nickname" required maxlength="24"></div><div class="field"><label>Código de convite do professor</label><input name="invite_code" required></div><div class="field"><label>Turma opcional</label><select name="class_id"><option value="">Sem turma por enquanto</option></select></div><button class="btn gold">Criar conta de professor</button></form>`;fetch("/api/public/classes").then(r=>r.json()).then(cs=>{const sel=document.querySelector('[name="class_id"]');cs.forEach(c=>{const o=document.createElement("option");o.value=c.id;o.textContent=`${c.name} · ${c.clan_name}`;sel.appendChild(o)})});document.querySelector("#teacherForm").onsubmit=async e=>{e.preventDefault();try{const r=await api("/api/auth/register-teacher",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});box.innerHTML=`<div class="hero"><h2>🧑‍🏫 Professor cadastrado!</h2><h1>${esc(r.access_code)}</h1><p class="muted">Guarde o código de acesso.</p><button class="btn" onclick="location.href='/teacher'">Abrir painel</button></div>`;}catch(err){toast(err.message)}}};
  document.querySelector("#showLogin").onclick=loginForm;document.querySelector("#showStudent").onclick=studentForm;document.querySelector("#showTeacher").onclick=teacherForm; loginForm();
}

function renderDashboard(){
  const pct=Math.min(100,Math.round(user.xp/(user.level*100)*100));
  layout("Painel do Aventureiro",`<section class="hero pop"><div class="row"><div class="avatar">${esc(user.nickname[0]?.toUpperCase()||"A")}</div><div><h2 style="margin:0">Bem-vindo, ${esc(user.nickname)}!</h2><div class="muted">${user.clan?.symbol||"✦"} ${esc(user.clan?.name||"Sem clã")} · Turma ${esc(user.class?.name||"-")}</div></div></div><div style="margin-top:16px"><div class="between"><span>XP para o nível ${user.level+1}</span><b>${user.xp}/${user.level*100}</b></div><div class="progress"><span style="width:${pct}%"></span></div></div></section>
  <div class="grid grid-4" style="margin-top:14px"><div class="card stat"><div class="label">Nível</div><div class="value">⭐ ${user.level}</div></div><div class="card stat"><div class="label">HP</div><div class="value">❤️ ${user.hp}</div></div><div class="card stat"><div class="label">Moedas</div><div class="value">🪙 ${user.coins}</div></div><div class="card stat"><div class="label">Sequência</div><div class="value">🔥 ${user.streak}</div></div></div>
  <div class="card" style="margin-top:14px"><div class="between"><div><h3 style="margin:0">Equipamento</h3><div class="muted">Seus bônus entram nas batalhas.</div></div><button class="btn small secondary" onclick="go('/inventory')">Gerenciar</button></div><div class="grid grid-3" style="margin-top:12px"><div><span class="muted">Fruta</span><strong style="display:block">${user.equipped?.fruit?.icon||'—'} ${esc(user.equipped?.fruit?.name||'Nenhuma')}</strong></div><div><span class="muted">Espada</span><strong style="display:block">${user.equipped?.weapon?.icon||'—'} ${esc(user.equipped?.weapon?.name||'Nenhuma')}</strong></div><div><span class="muted">Bônus ATK</span><strong style="display:block">+${user.bonuses?.attack||0}</strong></div></div></div>
  <div class="grid grid-3" style="margin-top:14px"><div class="card"><h3>⚔️ Batalhar</h3><p class="muted">Desafie colegas e responda para atacar.</p><button class="btn" onclick="go('/battle')">Abrir arena</button></div><div class="card"><h3>📚 Estudar</h3><p class="muted">Ganhe XP, moedas e pontos para seu clã.</p><button class="btn" onclick="go('/subjects')">Começar sessão</button></div><div class="card"><h3>🏆 Ranking</h3><p class="muted">Veja como seu estudo movimenta a academia.</p><button class="btn" onclick="go('/ranking')">Ver ranking</button></div></div>`);
}

function renderProfile(){
  api("/api/profile").then(d=>layout("Meu Perfil",`<div class="grid grid-2"><div class="card"><div class="row"><div class="avatar">${esc(user.nickname[0]?.toUpperCase())}</div><div><h2>${esc(user.nickname)}</h2><div class="muted">${esc(user.name)} · ${esc(user.role)}</div></div></div><hr style="border-color:var(--border);border-width:1px 0 0;margin:18px 0"><div class="grid grid-2"><div><span class="muted">Nível</span><h3>${user.level}</h3></div><div><span class="muted">XP</span><h3>${user.xp}</h3></div><div><span class="muted">Ataque</span><h3>${user.attack}</h3></div><div><span class="muted">Defesa</span><h3>${user.defense}</h3></div></div></div><div class="card"><h2>📈 Progresso acadêmico</h2><div class="list">${d.progress.map(p=>`<div class="list-item"><div class="between"><strong>${esc(p.subject)}</strong><b>${p.accuracy||0}%</b></div><div class="progress" style="margin-top:8px"><span style="width:${p.accuracy||0}%"></span></div><small class="muted">${p.answers||0} respostas</small></div>`).join("")}</div></div></div>`));
}

function renderSubjects(){
  const subjects=bootstrap.subjects;
  layout("Biblioteca de Estudos",`<div class="grid grid-3">${subjects.map(s=>`<div class="card"><div class="between"><h2>${esc(s.name)}</h2><span class="pill">📘</span></div><p class="muted">Treine, ganhe XP e fortaleça seu clã.</p><button class="btn" onclick="startStudy(${s.id},'${esc(s.name)}')">Estudar</button></div>`).join("")}</div><div id="studyArea" style="margin-top:14px"></div>`);
}
window.startStudy=async(id,name)=>{
  const area=document.querySelector("#studyArea"); area.innerHTML=`<div class="card"><div class="muted">Carregando questão de ${esc(name)}...</div></div>`;
  try{const q=await loadQuestion(id);renderStudyQuestion(area,q)}catch(e){area.innerHTML=`<div class="card empty">${esc(e.message)}</div>`}
};
function renderStudyQuestion(area,q){
  const started=Date.now();
  area.innerHTML=`<div class="card question pop"><div class="between"><span class="pill">${esc(q.subject_name)} · ${esc(q.difficulty)}</span><span class="pill">+${q.xp} XP</span></div><h2>${esc(q.prompt)}</h2><div id="answers">${q.options?.map(o=>`<button class="option" data-a="${esc(o)}">${esc(o)}</button>`).join("")||`<div class="field"><input id="textAnswer" placeholder="Digite sua resposta"></div><button class="btn" id="sendText">Responder</button>`}</div><div id="feedback"></div></div>`;
  area.querySelectorAll(".option").forEach(b=>b.onclick=()=>submitStudy(q,b.dataset.a,Date.now()-started,area));
  area.querySelector("#sendText")?.addEventListener("click",()=>submitStudy(q,area.querySelector("#textAnswer").value,Date.now()-started,area));
}
async function submitStudy(q,a,ms,area){
  area.querySelectorAll("button").forEach(b=>b.disabled=true);
  try{const r=await answerQuestion(q.id,a,ms);area.querySelector("#feedback").innerHTML=`<div class="card ${r.correct?"":"shake"}" style="margin-top:12px"><h3>${r.correct?"✅ ACERTOU!":"❌ AINDA NÃO"}</h3><p>${esc(r.explanation)}</p><p>+${r.xp} XP · +${r.coins} moedas</p><button class="btn" onclick="startStudy(${q.subject_id||""},'')">Próxima questão</button></div>`;user=await me();}catch(e){toast(e.message)}
}

function renderClan(){clan().then(d=>layout("Meu Clã",d.clan?`<div class="hero"><div class="row"><div class="avatar">${d.clan.symbol}</div><div><h2>${esc(d.clan.name)}</h2><p class="muted">${esc(d.clan.description)}</p></div></div><div class="grid grid-3" style="margin-top:15px"><div class="card stat"><div class="label">Pontos</div><div class="value">${d.clan.points}</div></div><div class="card stat"><div class="label">Membros</div><div class="value">${d.members.length}</div></div><div class="card stat"><div class="label">Moedas do clã</div><div class="value">${d.clan.coins}</div></div></div></div><div class="card" style="margin-top:14px"><h2>Membros da turma</h2><div class="list">${d.members.map((m,i)=>`<div class="list-item between"><span>#${i+1} ${esc(m.nickname)}</span><span class="pill">LV ${m.level} · ${m.xp} XP</span></div>`).join("")}</div></div>`:`<div class="card empty">Você ainda não pertence a um clã.</div>`));}

function renderRanking(){api("/api/ranking").then(rows=>layout("Ranking da Academia",`<div class="card"><p class="muted">Pontuação baseada principalmente em aprendizagem e acertos, não em tempo de tela.</p><div class="table-wrap"><table class="table"><thead><tr><th>#</th><th>Aluno</th><th>Clã</th><th>Nível</th><th>Pontos</th></tr></thead><tbody>${rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.nickname)}</td><td>${r.symbol||"✦"} ${esc(r.clan_name||"-")}</td><td>${r.level}</td><td>${r.points}</td></tr>`).join("")}</tbody></table></div></div>`));}

function renderInventory(){inventory().then(items=>layout("Inventário",items.length?`<div class="grid grid-3">${items.map(x=>`<div class="card"><div class="between"><span style="font-size:34px">${x.data.icon}</span><span class="pill">x${x.quantity}</span></div><h3>${esc(x.data.name)}</h3><div class="muted">${esc(x.data.description)}</div><p class="rarity-${x.data.rarity}">${x.data.rarity}</p><div class="between"><span class="pill">${x.equipped?'EQUIPADO':'Guardado'}</span>${x.item_kind!=='ITEM'||true?`<button class="btn small ${x.equipped?'secondary':''}" onclick="equipItem('${x.item_kind}',${x.item_id})">${x.equipped?'Equipado':'Equipar'}</button>`:''}</div></div>`).join("")}</div>`:`<div class="card empty">Seu inventário está vazio. Visite a loja para começar sua coleção.</div>`);}

function renderShop(){shop().then(d=>layout("Mercado da Academia",`<div class="hero" style="margin-bottom:14px"><div class="between"><div><h2>🎲 Sorteio de Frutas</h2><p class="muted">Custo: 250 moedas. Probabilidades transparentes: Comum 60% · Incomum 25% · Raro 10% · Épico 4% · Lendário 1%.</p></div><button class="btn gold" onclick="drawFruit()">Sortear</button></div></div><div class="grid grid-3">${[...d.fruits.map(x=>({...x,kind:"FRUIT"})),...d.weapons.map(x=>({...x,kind:"WEAPON"})),...d.items.map(x=>({...x,kind:"ITEM"}))].map(x=>`<div class="card"><div class="between"><span style="font-size:36px">${x.icon}</span><span class="pill rarity-${x.rarity}">${x.rarity}</span></div><h3>${esc(x.name)}</h3><p class="muted">${esc(x.description)}</p><p>🪙 <b>${x.price}</b></p><button class="btn" onclick="buyItem('${x.kind}',${x.id})">Comprar</button></div>`).join("")}</div>`));}
window.buyItem=async(k,id)=>{try{await buy(k,id);user=await me();toast("Item adicionado ao inventário!");renderShop()}catch(e){toast(e.message)}};
window.equipItem=async(k,id)=>{try{const r=await api('/api/inventory/equip',{method:'POST',body:JSON.stringify({kind:k,id})});user=r.user;toast('Equipamento atualizado!');renderInventory()}catch(e){toast(e.message)}};
function renderFruits(){shop().then(d=>layout("Frutas Especiais",`<div class="hero"><h2>🍈 Coleção de criaturas</h2><p class="muted">A Fruta da Capivara é lendária e rara, mas não exige jogar por horas. Ela pode aparecer em eventos, sorteios e recompensas especiais.</p></div><div class="grid grid-3" style="margin-top:14px">${d.fruits.map(x=>`<div class="card"><div style="font-size:46px">${x.icon}</div><h2>${esc(x.name)}</h2><span class="pill rarity-${x.rarity}">${x.rarity}</span><p>${esc(x.description)}</p><p class="muted">${esc(x.ability)}</p><b>🪙 ${x.price}</b></div>`).join("")}</div>`));}

function renderMissions(){api("/api/missions").then(ms=>layout("Missões",`<div class="grid grid-2">${ms.map(m=>`<div class="card"><div class="between"><h2>${esc(m.name)}</h2><span class="pill">${m.progress}/${m.target}</span></div><p class="muted">${esc(m.description)}</p><div class="progress"><span style="width:${Math.min(100,m.progress/m.target*100)}%"></span></div><p>🎁 +${m.reward_xp} XP · +${m.reward_coins} moedas</p>${m.progress>=m.target&&!m.claimed?`<button class="btn gold" onclick="claimMission(${m.id)">Resgatar</button>`:`<span class="muted">${m.claimed?"Resgatada":"Continue praticando"}</span>`}</div>`).join("")}</div>`));}
window.claimMission=async id=>{try{await api("/api/missions/"+id+"/claim",{method:"POST"});user=await me();toast("Recompensa recebida!");renderMissions()}catch(e){toast(e.message)}};

function renderBattle(){
  layout("Arena de Batalhas",`<div class="grid grid-2"><div class="card"><div class="between"><h2>🟢 Jogadores online</h2><span class="pill" id="socketStatus">Conectando...</span></div><p class="muted">O status abaixo confirma a conexão real com o servidor Socket.IO.</p><div id="online" class="list"><div class="empty">Carregando...</div></div></div><div id="battleHost"><div class="card empty">Desafie um colega para iniciar.</div></div></div>`);
  const s=getSocket(); s.off("online:update");s.off("challenge:incoming");s.off("challenge:sent");s.off("battle:started");s.off("system:connected");s.off("challenge:error");
  s.on("system:connected",()=>{const st=document.querySelector("#socketStatus");if(st){st.textContent="🟢 ONLINE";st.className="pill";}});
  s.on("online:update",ids=>{const online=document.querySelector("#online");if(!online)return;const others=ids.filter(id=>id!==user.id);online.innerHTML=others.length?others.map(id=>`<div class="list-item between"><span>🎓 Jogador #${id}</span><button class="btn small" onclick="challenge(${id})">Desafiar</button></div>`).join(""):`<div class="empty">Nenhum colega online agora. Abra outra janela para testar.</div>`;});
  s.on("challenge:incoming",d=>{const ok=confirm(`${d.fromNickname} desafiou você para uma batalha. Aceitar?`);s.emit("challenge:respond",{fromId:d.fromId,accept:ok});});
  s.on("challenge:sent",d=>toast(`Desafio enviado para ${d.targetNickname}.`));
  s.on("challenge:error",d=>toast(d.message));
  s.on("battle:started",d=>{const host=document.querySelector("#battleHost");if(!host)return;host.innerHTML="";host.appendChild(battleView({...d,userId:user.id}));if(d.turn===user.id)s.emit("battle:action",{battleId:d.battleId,action:"ATTACK"});});
}
window.challenge=id=>getSocket().emit("challenge:send",{targetId:id});

function renderTeacher(){
  if(user.role==="STUDENT")return go("/dashboard");
  Promise.all([api("/api/teacher/questions"),teacherStats(),api("/api/teacher/assignments")]).then(([qs,st,assignments])=>layout("Painel do Professor",`<div class="grid grid-4"><div class="card stat"><div class="label">Respostas</div><div class="value">${st.global.total}</div></div><div class="card stat"><div class="label">Acerto</div><div class="value">${st.global.accuracy}%</div></div><div class="card stat"><div class="label">Alunos</div><div class="value">${st.global.students}</div></div><div class="card stat"><div class="label">Turmas</div><div class="value">${st.global.classes}</div></div></div><div class="grid grid-2" style="margin-top:14px"><div class="card"><h2>➕ Criar pergunta</h2><form id="qform" class="form"><div class="field"><label>Matéria</label><select name="subject_id">${bootstrap.subjects.map(s=>`<option value="${s.id}">${esc(s.name)}</option>`).join("")}</select></div><div class="field"><label>Assunto</label><input name="topic" required></div><div class="field"><label>Série</label><input name="grade" value="Fundamental"></div><div class="field"><label>Dificuldade</label><select name="difficulty"><option>EASY</option><option>MEDIUM</option><option>HARD</option><option>EXPERT</option></select></div><div class="field"><label>Tipo</label><select name="type"><option>MCQ</option><option>TF</option><option>NUMBER</option><option>TEXT</option></select></div><div class="field"><label>Enunciado</label><textarea name="prompt" required></textarea></div><div class="field"><label>Alternativas separadas por |</label><input name="options"></div><div class="field"><label>Resposta correta</label><input name="correct_answer" required></div><div class="field"><label>Explicação</label><textarea name="explanation"></textarea></div><div class="grid grid-2"><div class="field"><label>XP</label><input type="number" name="xp" value="10"></div><div class="field"><label>Moedas</label><input type="number" name="coins" value="5"></div></div><button class="btn">Salvar pergunta</button></form></div><div class="card"><h2>🎯 Escolher perguntas para uma turma</h2><div class="field"><label>Turma</label><select id="assignClass">${bootstrap.classes.map(c=>`<option value="${c.id}">${esc(c.name)} · ${esc(c.clan_name)}</option>`).join("")}</select></div><div class="list" style="margin-top:12px;max-height:520px;overflow:auto">${qs.map(q=>`<div class="list-item"><div><strong>${esc(q.prompt)}</strong><div class="muted">${esc(q.subject_name)} · ${q.difficulty}</div></div><button class="btn small" onclick="assignQuestion(${q.id})">Selecionar</button></div>`).join("")}</div><h3>Selecionadas</h3><div class="list">${assignments.map(a=>`<div class="list-item between"><span>${esc(a.prompt)} · ${esc(a.class_name)}</span><button class="btn small danger" onclick="unassignQuestion(${a.class_id},${a.question_id})">Remover</button></div>`).join("")||'<div class="empty">Nenhuma pergunta selecionada.</div>'}</div></div></div><div class="card" style="margin-top:14px"><h2>📊 Desempenho por matéria</h2><div class="grid grid-3">${st.bySubject.map(x=>`<div class="list-item"><div class="between"><strong>${esc(x.name)}</strong><b>${x.accuracy||0}%</b></div><div class="progress"><span style="width:${x.accuracy||0}%"></span></div></div>`).join("")}</div></div>`));
  setTimeout(()=>document.querySelector("#qform")?.addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.target),data=Object.fromEntries(f);data.options=data.options?data.options.split("|").map(x=>x.trim()):[];try{await api("/api/teacher/questions",{method:"POST",body:JSON.stringify(data)});toast("Pergunta criada!");renderTeacher()}catch(err){toast(err.message)}}),0);
}
window.assignQuestion=async id=>{try{const class_id=document.querySelector("#assignClass").value;await api("/api/teacher/assignments",{method:"POST",body:JSON.stringify({class_id,question_id:id})});toast("Pergunta selecionada para a turma!");renderTeacher()}catch(e){toast(e.message)}};
window.unassignQuestion=async(class_id,question_id)=>{try{await api("/api/teacher/assignments",{method:"DELETE",body:JSON.stringify({class_id,question_id})});renderTeacher()}catch(e){toast(e.message)}};
window.deleteQ=async id=>{try{await api("/api/teacher/questions/"+id,{method:"DELETE"});toast("Pergunta excluída.");renderTeacher()}catch(e){toast(e.message)}};

function renderAdmin(){
  if(user.role!=="ADMIN")return go("/dashboard");
  Promise.all([adminOverview(),api("/api/admin/teacher-invites")]).then(([d,invites])=>layout("Central do Administrador",`<div class="grid grid-4"><div class="card stat"><div class="label">Alunos</div><div class="value">${d.stats.students}</div></div><div class="card stat"><div class="label">Turmas</div><div class="value">${d.stats.classes}</div></div><div class="card stat"><div class="label">Respostas</div><div class="value">${d.stats.total}</div></div><div class="card stat"><div class="label">Acerto</div><div class="value">${d.stats.accuracy}%</div></div></div>
  <div class="grid grid-3" style="margin-top:14px">
    <div class="card"><h2>🧑‍🏫 Código de professor</h2><form id="inviteForm" class="form"><div class="field"><label>Nome</label><input name="label" value="Convite escolar"></div><div class="field"><label>Usos</label><input name="max_uses" type="number" value="10" min="1" max="10000"></div><button class="btn gold">Gerar código</button></form><div id="inviteResult"></div></div>
    <div class="card"><h2>🏰 Criar clã</h2><form id="clanForm" class="form"><div class="field"><label>Nome</label><input name="name" required></div><div class="field"><label>Símbolo</label><input name="symbol" value="✦"></div><div class="field"><label>Cor</label><input name="color" value="#7c5cff"></div><div class="field"><label>Descrição</label><input name="description"></div><button class="btn">Criar clã</button></form></div>
    <div class="card"><h2>🏫 Criar turma</h2><form id="classForm" class="form"><div class="field"><label>Nome da turma</label><input name="name" placeholder="901" required></div><div class="field"><label>Série</label><input name="grade" value="Fundamental"></div><div class="field"><label>Clã</label><select name="clan_id">${d.clans?.map(c=>`<option value="${c.id}">${esc(c.symbol)} ${esc(c.name)}</option>`).join("")||bootstrap.clans.map(c=>`<option value="${c.id}">${esc(c.symbol)} ${esc(c.name)}</option>`).join("")}</select></div><button class="btn">Criar turma</button></form></div>
  </div>
  <div class="grid grid-2" style="margin-top:14px"><div class="card"><h2>👥 Usuários</h2><div class="table-wrap"><table class="table"><thead><tr><th>ID</th><th>Apelido</th><th>Função</th><th>Código</th><th></th></tr></thead><tbody>${d.users.map(u=>`<tr><td>${u.id}</td><td>${esc(u.nickname)}</td><td>${u.role}</td><td>${esc(u.access_code)}</td><td>${u.id!==user.id?`<button class="btn small danger" onclick="removeUser(${u.id})">Excluir</button>`:""}</td></tr>`).join("")}</tbody></table></div></div><div class="card"><h2>🎟️ Convites</h2><div class="list">${invites.map(i=>`<div class="list-item between"><span>${esc(i.label)} · ${i.uses}/${i.max_uses}</span><span class="pill">${i.active?"ATIVO":"ENCERRADO"}</span></div>`).join("")}</div><p class="muted">O código do convite é mostrado apenas no momento em que é criado.</p></div></div>
  <div class="card" style="margin-top:14px"><h2>🏫 Turmas e clãs</h2><div class="grid grid-3">${d.classes.map(c=>`<div class="list-item"><strong>Turma ${esc(c.name)}</strong><div class="muted">${esc(c.clan_name)} · ${esc(c.grade)}</div></div>`).join("")}</div></div>`));
  setTimeout(()=>{
    document.querySelector("#inviteForm")?.addEventListener("submit",async e=>{e.preventDefault();try{const r=await api("/api/admin/teacher-invites",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});document.querySelector("#inviteResult").innerHTML=`<div class="hero" style="margin-top:12px"><strong>Novo código:</strong><h2>${esc(r.code)}</h2><p class="muted">Envie este código aos professores autorizados.</p></div>`;}catch(err){toast(err.message)}});
    document.querySelector("#clanForm")?.addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/clans",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});toast("Clã criado!");renderAdmin()}catch(err){toast(err.message)}});
    document.querySelector("#classForm")?.addEventListener("submit",async e=>{e.preventDefault();try{await api("/api/admin/classes",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target)))});toast("Turma criada!");renderAdmin()}catch(err){toast(err.message)}});
  },0);
}

window.removeUser=async id=>{if(!confirm("Excluir este usuário?"))return;try{await api("/api/admin/users/"+id,{method:"DELETE"});toast("Usuário removido.");renderAdmin()}catch(e){toast(e.message)}};

init();

window.drawFruit=async()=>{try{const r=await api("/api/gacha/draw",{method:"POST"});user=r.user;toast(`🎉 Você ganhou ${r.fruit.name}!`);renderShop()}catch(e){toast(e.message)}};
