import {api} from "./auth.js";
export async function clan(){return api("/api/clan")}
