import {getSocket} from "./multiplayer.js";
export function battleView(state){
  const s=getSocket(); let current=null; let startedAt=0;
  const el=document.createElement("div"); el.className="battle-arena";
  el.innerHTML=`<div class="card"><div class="between"><div><strong>⚔️ Duelo em tempo real</strong><div class="muted">O servidor valida cada resposta, dano e recompensa.</div></div><span class="pill" id="turn">Conectando...</span></div></div>
  <div class="grid grid-2"><div class="fighter"><div class="between"><strong>Você</strong><span id="myhp">100</span></div><div class="hpbar"><span id="mybar" style="width:100%"></span></div></div><div class="fighter"><div class="between"><strong>Adversário</strong><span id="opphp">100</span></div><div class="hpbar"><span id="oppbar" style="width:100%"></span></div></div></div>
  <div class="card" id="battleContent"><div class="actions"><button class="btn" data-action="ATTACK">⚔️ Ataque</button><button class="btn secondary" data-action="DEFEND">🛡️ Defesa</button><button class="btn gold" data-action="ABILITY">✨ Habilidade</button><button class="btn danger" data-action="FLEE">🏃 Fugir</button></div><div id="questionArea" style="margin-top:14px"></div></div>`;
  const setTurn=t=>{el.querySelector("#turn").textContent=t===state.userId?"🟢 Sua vez":"🔴 Vez do adversário";el.querySelectorAll("[data-action]").forEach(b=>b.disabled=t!==state.userId);};
  const sendAnswer=answer=>{if(!current)return;s.emit("battle:answer",{battleId:state.battleId,questionId:current.id,answer,responseMs:Date.now()-startedAt});current=null;el.querySelector("#questionArea").innerHTML=`<div class="empty">Resposta enviada ao servidor...</div>`;};
  const renderQ=q=>{
    current=q;startedAt=Date.now();const box=el.querySelector("#questionArea");
    box.innerHTML=`<div class="question pop"><span class="pill">${q.subject_name} · ${q.difficulty}</span><h2>${escapeHtml(q.prompt)}</h2><div id="battleAnswers"></div></div>`;
    const answers=box.querySelector("#battleAnswers"), options=q.options||[];
    if(options.length){options.forEach(o=>{const b=document.createElement("button");b.className="option";b.textContent=o;b.addEventListener("click",()=>sendAnswer(o));answers.appendChild(b);});}
    else {const wrap=document.createElement("div");wrap.className="field";wrap.innerHTML=`<label for="battleTextAnswer">Sua resposta</label><input id="battleTextAnswer" inputmode="decimal" autocomplete="off">`;answers.appendChild(wrap);const b=document.createElement("button");b.className="btn";b.style.marginTop="10px";b.textContent="Responder";b.addEventListener("click",()=>sendAnswer(box.querySelector("#battleTextAnswer").value));answers.appendChild(b);}
  };
  el.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>s.emit("battle:action",{battleId:state.battleId,action:b.dataset.action})));
  s.on("battle:turn",d=>{setTurn(d.turn);});
  s.on("battle:question",renderQ);
  s.on("battle:result",r=>{el.querySelector("#myhp").textContent=r.yourHp??el.querySelector("#myhp").textContent;if(r.opponentHp!==null){el.querySelector("#opphp").textContent=r.opponentHp;el.querySelector("#oppbar").style.width=Math.max(0,r.opponentHp)+"%";} toast(r.correct?`✅ Acertou! ${r.critical?"CRÍTICO! ":""}${r.damage?`-${r.damage} HP`:"Defesa ativa!"}`:"❌ Errou. Estude e tente de novo!");});
  s.on("battle:incomingResult",r=>{if(r.yourHp!=null){el.querySelector("#myhp").textContent=r.yourHp;el.querySelector("#mybar").style.width=Math.max(0,r.yourHp)+"%";}toast(r.damage?`💥 Você recebeu ${r.damage} de dano.`:"🛡️ O ataque adversário falhou.");});
  s.on("battle:finished",r=>{setTurn(-1);toast(r.winnerId===state.userId?"🏆 Vitória!":"📚 Batalha encerrada. Você ganhou XP pela participação.");});
  setTurn(state.turn); return el;
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function toast(m){const t=document.querySelector("#toast");t.textContent=m;t.classList.remove("hidden");setTimeout(()=>t.classList.add("hidden"),2600);}
