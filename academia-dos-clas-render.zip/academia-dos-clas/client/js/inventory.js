import {api} from "./auth.js";
export async function inventory(){return api("/api/inventory")}
export async function buy(kind,id){return api("/api/shop/buy",{method:"POST",body:JSON.stringify({kind,id})})}
export async function shop(){return api("/api/shop")}
