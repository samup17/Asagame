import {api} from "./auth.js";
export async function loadQuestion(subjectId="",difficulty=""){
  const qs=new URLSearchParams(); if(subjectId)qs.set("subjectId",subjectId); if(difficulty)qs.set("difficulty",difficulty);
  return api("/api/question?"+qs.toString());
}
export async function answerQuestion(questionId,answer,responseMs){
  return api("/api/question/answer",{method:"POST",body:JSON.stringify({questionId,answer,responseMs})});
}
