export async function login(code){
  const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code})});
  const data=await r.json(); if(!r.ok) throw new Error(data.error||"Falha no login"); return data;
}
export async function logout(){await fetch("/api/auth/logout",{method:"POST"}); location.href="/login";}
export async function me(){const r=await fetch("/api/auth/me"); if(!r.ok) return null; return (await r.json()).user;}
export async function api(url,options={}){
  const r=await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||"Erro na requisição");
  return data;
}
