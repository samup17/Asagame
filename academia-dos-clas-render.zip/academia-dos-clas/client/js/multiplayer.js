let socket=null;
let heartbeat=null;
export function connect(){
  if(!socket){
    socket=window.io({transports:["websocket","polling"],withCredentials:true,reconnection:true,reconnectionAttempts:Infinity,reconnectionDelay:800,reconnectionDelayMax:5000,timeout:10000});
    socket.on("connect",()=>{
      const t=document.querySelector("#toast");
      if(t){t.textContent="🟢 Multiplayer conectado";t.classList.remove("hidden");setTimeout(()=>t.classList.add("hidden"),1800);}
      if(heartbeat)clearInterval(heartbeat);
      heartbeat=setInterval(()=>{if(socket?.connected)socket.emit("battle:ping");},20000);
    });
    socket.on("disconnect",()=>{
      const t=document.querySelector("#toast");
      if(t){t.textContent="🟠 Multiplayer desconectado. Reconectando...";t.classList.remove("hidden");}
    });
    socket.on("connect_error",e=>{
      const t=document.querySelector("#toast");
      if(t){t.textContent="Servidor multiplayer indisponível. Tentando reconectar...";t.classList.remove("hidden");}
    });
  }
  return socket;
}
export function getSocket(){return connect();}
