const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const db = require("./database");

function publicUser(user) {
  if (!user) return null;
  const clan = user.class_id
    ? db.prepare(`SELECT c.* FROM classes cl JOIN clans c ON c.id=cl.clan_id WHERE cl.id=?`).get(user.class_id)
    : null;
  const cls = user.class_id ? db.prepare("SELECT * FROM classes WHERE id=?").get(user.class_id) : null;
  const fruit = db.prepare(`SELECT f.* FROM inventory i JOIN fruits f ON f.id=i.item_id WHERE i.user_id=? AND i.item_kind='FRUIT' AND i.equipped=1 LIMIT 1`).get(user.id);
  const weapon = db.prepare(`SELECT w.* FROM inventory i JOIN weapons w ON w.id=i.item_id WHERE i.user_id=? AND i.item_kind='WEAPON' AND i.equipped=1 LIMIT 1`).get(user.id);
  const accessory = db.prepare(`SELECT x.* FROM inventory i JOIN items x ON x.id=i.item_id WHERE i.user_id=? AND i.item_kind='ITEM' AND i.equipped=1 LIMIT 1`).get(user.id);
  let bonuses={attack:0,defense:0,accuracy:0,crit:0,hp:0};
  if(weapon) bonuses={...bonuses,attack:bonuses.attack+weapon.attack,defense:bonuses.defense+weapon.defense,crit:bonuses.crit+weapon.crit};
  if(accessory) bonuses={...bonuses,attack:bonuses.attack+accessory.attack,defense:bonuses.defense+accessory.defense,crit:bonuses.crit+accessory.crit,hp:bonuses.hp+accessory.hp};
  if(fruit){try{const b=JSON.parse(fruit.bonus_json||'{}'); for(const k of Object.keys(bonuses)) bonuses[k]+=Number(b[k]||0);}catch{}}
  return {...user, access_code: undefined, clan, class: cls, equipped:{fruit:fruit||null,weapon:weapon||null,accessory:accessory||null}, bonuses, derived:{attack:user.attack+bonuses.attack,defense:user.defense+bonuses.defense,accuracy:user.accuracy+bonuses.accuracy,crit:user.crit+bonuses.crit,max_hp:user.max_hp+bonuses.hp}};
}


function generateAccessCode() {
  let code;
  do {
    const a = crypto.randomBytes(3).toString("hex").toUpperCase();
    const b = crypto.randomBytes(2).toString("hex").toUpperCase();
    code = `ACD-${a}-${b}`;
  } while (db.prepare("SELECT 1 FROM users WHERE access_code=?").get(code));
  return code;
}

function createStudent({name,nickname,classId}) {
  const safeNickname = String(nickname||"").trim().slice(0,24);
  const safeName = String(name||safeNickname).trim().slice(0,60);
  if (!safeNickname || safeNickname.length < 2) throw new Error("Apelido inválido.");
  if (classId) {
    const exists = db.prepare("SELECT id FROM classes WHERE id=?").get(Number(classId));
    if (!exists) throw new Error("Turma inválida.");
  }
  const code=generateAccessCode();
  const id=db.prepare(`INSERT INTO users(name,nickname,access_code,role,class_id) VALUES(?,?,?,?,?)`)
    .run(safeName,safeNickname,code,"STUDENT",classId?Number(classId):null).lastInsertRowid;
  return {id,code,user:publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(id))};
}

function consumeTeacherInvite(code) {
  const rows=db.prepare("SELECT * FROM teacher_invites WHERE active=1 AND uses<max_uses ORDER BY id").all();
  for (const row of rows) {
    if (bcrypt.compareSync(String(code||""), row.code_hash)) {
      db.prepare("UPDATE teacher_invites SET uses=uses+1,active=CASE WHEN uses+1>=max_uses THEN 0 ELSE 1 END WHERE id=?").run(row.id);
      return true;
    }
  }
  return false;
}

function createTeacher({name,nickname,classId,inviteCode}) {
  if (!consumeTeacherInvite(inviteCode)) throw new Error("Código de professor inválido ou esgotado.");
  const safeNickname=String(nickname||"").trim().slice(0,24);
  const safeName=String(name||safeNickname).trim().slice(0,60);
  if (!safeNickname || safeNickname.length<2) throw new Error("Apelido inválido.");
  const code=generateAccessCode();
  const id=db.prepare("INSERT INTO users(name,nickname,access_code,role,class_id) VALUES(?,?,?,?,?)")
    .run(safeName,safeNickname,code,"TEACHER",classId?Number(classId):null).lastInsertRowid;
  return {id,code,user:publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(id))};
}

function loginByCode(code) {
  const user = db.prepare("SELECT * FROM users WHERE access_code=?").get(String(code).trim());
  return user ? publicUser(user) : null;
}

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({error:"Não autenticado."});
  next();
}

function requireRole(...roles) {
  return (req,res,next)=>{
    if (!req.session.userId) return res.status(401).json({error:"Não autenticado."});
    const user = db.prepare("SELECT role FROM users WHERE id=?").get(req.session.userId);
    if (!user || !roles.includes(user.role)) return res.status(403).json({error:"Permissão insuficiente."});
    next();
  };
}

function refreshSessionUser(req) {
  const user = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.userId);
  return publicUser(user);
}

module.exports = { publicUser, loginByCode, requireAuth, requireRole, refreshSessionUser, createStudent, createTeacher, generateAccessCode };
