const db = require("./database");

function addCoins(userId, amount, reason) {
  const safe = Math.max(0, Math.floor(Number(amount) || 0));
  if (!safe) return;
  db.prepare("UPDATE users SET coins=coins+? WHERE id=?").run(safe,userId);
  db.prepare("INSERT INTO transactions(user_id,kind,amount,reason) VALUES(?,?,?,?)").run(userId,"CREDIT",safe,reason);
}
function spendCoins(userId, amount, reason) {
  const safe = Math.max(0, Math.floor(Number(amount) || 0));
  const result = db.prepare("UPDATE users SET coins=coins-? WHERE id=? AND coins>=?").run(safe,userId,safe);
  if (!result.changes) return false;
  db.prepare("INSERT INTO transactions(user_id,kind,amount,reason) VALUES(?,?,?,?)").run(userId,"DEBIT",safe,reason);
  return true;
}
function addXp(userId, amount) {
  let user = db.prepare("SELECT level,xp FROM users WHERE id=?").get(userId);
  let xp = user.xp + Math.max(0, Math.floor(Number(amount)||0));
  let level = user.level;
  const levels = [];
  while (xp >= level * 100) {
    xp -= level * 100;
    level++;
    levels.push(level);
  }
  db.prepare("UPDATE users SET xp=?,level=? WHERE id=?").run(xp,level,userId);
  return {level, xp, leveledUp: levels.length > 0, levels};
}
function addClanPoints(userId, points) {
  const row = db.prepare(`SELECT cl.id FROM users u JOIN classes c ON c.id=u.class_id JOIN clans cl ON cl.id=c.clan_id WHERE u.id=?`).get(userId);
  if (row) db.prepare("UPDATE clans SET points=points+? WHERE id=?").run(Math.max(0,points),row.id);
}
module.exports = {addCoins,spendCoins,addXp,addClanPoints};

function ensureMissionRows(userId) {
  const missions = db.prepare("SELECT id FROM missions").all();
  const stmt = db.prepare("INSERT OR IGNORE INTO user_missions(user_id,mission_id) VALUES(?,?)");
  const tx = db.transaction(()=>missions.forEach(m=>stmt.run(userId,m.id)));
  tx();
}
function progressMission(userId, type, amount=1) {
  ensureMissionRows(userId);
  const rows = db.prepare(`SELECT um.*,m.goal_type,m.target FROM user_missions um JOIN missions m ON m.id=um.mission_id WHERE um.user_id=? AND m.goal_type=? AND um.claimed=0`).all(userId,type);
  for (const row of rows) {
    const progress = Math.min(row.target, row.progress + amount);
    db.prepare("UPDATE user_missions SET progress=?,completed=? WHERE user_id=? AND mission_id=?").run(progress, progress>=row.target?1:0, userId,row.mission_id);
  }
}
module.exports.ensureMissionRows=ensureMissionRows;
module.exports.progressMission=progressMission;
