const db = require("./database");
const {createQuestion} = require("./questions");

function stats() {
  const total = db.prepare("SELECT COUNT(*) c FROM answers").get().c;
  const correct = db.prepare("SELECT COUNT(*) c FROM answers WHERE correct=1").get().c;
  const students = db.prepare("SELECT COUNT(*) c FROM users WHERE role='STUDENT'").get().c;
  const classes = db.prepare("SELECT COUNT(*) c FROM classes").get().c;
  return {total,correct,accuracy:total ? Math.round(correct*100/total) : 0,students,classes};
}
module.exports = {stats,createQuestion};
