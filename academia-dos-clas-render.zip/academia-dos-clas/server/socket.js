const {Server} = require("socket.io");
const db = require("./database");
const {createBattle,getBattle,applyDamage,finishBattle,active} = require("./battle");
const {pickQuestionForBattle,validateAnswer} = require("./questions");
const {publicUser} = require("./auth");

function setup(httpServer, sessionMiddleware) {
  const io = new Server(httpServer, {cors:{origin:true,credentials:true}});
  io.engine.use(sessionMiddleware);
  io.use((socket,next)=>{
    const session = socket.request.session;
    if (!session || !session.userId) return next(new Error("Não autenticado"));
    socket.userId = Number(session.userId);
    const user=db.prepare("SELECT id,role FROM users WHERE id=?").get(socket.userId);
    if(!user) return next(new Error("Usuário não encontrado"));
    next();
  });

  const online = new Map();
  const emitOnline=()=>io.emit("online:update",Array.from(online.keys()).map(Number));
  const userRoom=id=>`user:${id}`;
  const battleRooms=id=>`battle:${id}`;

  io.on("connection", socket=>{
    online.set(socket.userId,socket.id);
    socket.join(userRoom(socket.userId));
    socket.emit("system:connected",{userId:socket.userId,serverTime:new Date().toISOString()});
    emitOnline();

    socket.on("challenge:send", ({targetId})=>{
      const target=Number(targetId);
      if(!Number.isInteger(target)||target===socket.userId||!online.has(target)) return socket.emit("challenge:error",{message:"Jogador não está online."});
      const challenger=db.prepare("SELECT nickname,role FROM users WHERE id=?").get(socket.userId);
      const targetUser=db.prepare("SELECT nickname,role FROM users WHERE id=?").get(target);
      if(!challenger||!targetUser||challenger.role!=="STUDENT"||targetUser.role!=="STUDENT") return socket.emit("challenge:error",{message:"Apenas estudantes podem duelar."});
      io.to(userRoom(target)).emit("challenge:incoming",{fromId:socket.userId,fromNickname:challenger.nickname});
      socket.emit("challenge:sent",{targetId:target,targetNickname:targetUser.nickname});
    });

    socket.on("challenge:respond", ({fromId,accept})=>{
      const a=Number(fromId);
      if(!online.has(a)) return socket.emit("challenge:error",{message:"O desafiante saiu."});
      if(!accept){io.to(userRoom(a)).emit("challenge:rejected",{byId:socket.userId});return;}
      const battle=createBattle(a,socket.userId);
      battle.players.forEach(uid=>io.to(userRoom(uid)).emit("battle:started",{battleId:battle.id,players:battle.players,turn:battle.turn}));
      io.to(battleRooms(battle.id)).emit("battle:state",{battleId:battle.id,turn:battle.turn});
    });

    socket.on("battle:action", ({battleId,action})=>{
      const b=getBattle(battleId); if(!b||!b.players.includes(socket.userId))return;
      if(b.turn!==socket.userId)return socket.emit("battle:error",{message:"Ainda não é sua vez."});
      const allowed=["ATTACK","DEFEND","ABILITY","FLEE"]; if(!allowed.includes(action))return;
      b.action=action;
      if(action==="FLEE"){
        const opponent=b.players.find(x=>x!==socket.userId); const result=finishBattle(battleId,opponent);
        b.players.forEach(uid=>io.to(userRoom(uid)).emit("battle:finished",{...result,fled:socket.userId})); return;
      }
      const q=pickQuestionForBattle(socket.userId,null,null);
      if(!q)return socket.emit("battle:error",{message:"Não há perguntas disponíveis para esta batalha."});
      b.currentQuestion={id:q.id,forUser:socket.userId,action};
      socket.emit("battle:question",q);
    });

    socket.on("battle:question", ({battleId})=>{
      const b=getBattle(battleId); if(!b||b.turn!==socket.userId)return;
      if(!b.currentQuestion){
        const q=pickQuestionForBattle(socket.userId,null,null); if(!q)return;
        b.currentQuestion={id:q.id,forUser:socket.userId,action:"ATTACK"}; socket.emit("battle:question",q);
      }
    });

    socket.on("battle:answer", ({battleId,questionId,answer,responseMs})=>{
      const b=getBattle(battleId); if(!b||b.turn!==socket.userId||!b.currentQuestion||b.currentQuestion.id!==Number(questionId))return;
      const result=validateAnswer(questionId,answer); const opponent=b.players.find(x=>x!==socket.userId);
      const me=publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(socket.userId));
      const action=b.currentQuestion.action||"ATTACK"; let damage=0,critical=false,guard=false;
      db.prepare(`INSERT INTO answers(user_id,question_id,answer,correct,response_ms,xp_gained,coins_gained) VALUES(?,?,?,?,?,?,?)`)
        .run(socket.userId,Number(questionId),String(answer??""),result.correct?1:0,Number(responseMs||0),0,0);
      if(result.correct){
        if(action==="DEFEND") guard=true;
        else { damage=me.derived.attack; const fast=Number(responseMs||99999)<5000; critical=Math.random()*100 < Math.min(50,me.derived.crit+(fast?5:0)); if(critical)damage*=2; if(action==="ABILITY")damage=Math.round(damage*1.35); }
      }
      let targetHp=null;
      if(damage>0){
        const opponentUser=publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(opponent));
        if(b.guardUsed[opponent]){ damage=Math.max(1,Math.round(damage*0.45)); b.guardUsed[opponent]=false; }
        if(opponentUser.equipped?.fruit?.name==="Fruta da Capivara" && !b.specialUsed[opponent]){
          damage=Math.max(1,Math.round(damage*0.70)); b.specialUsed[opponent]=true;
        }
        targetHp=applyDamage(battleId,opponent,damage);
      }
      b.currentQuestion=null;
      const myRow=db.prepare("SELECT hp,max_hp FROM battle_players WHERE battle_id=? AND user_id=?").get(battleId,socket.userId);
      b.guardUsed[socket.userId]=guard;
      io.to(userRoom(socket.userId)).emit("battle:result",{correct:result.correct,damage,critical,guard,yourHp:myRow.hp,opponentHp:targetHp});
      io.to(userRoom(opponent)).emit("battle:incomingResult",{correct:result.correct,damage,critical,guard,yourHp:targetHp,attackerId:socket.userId});
      if(targetHp!==null&&targetHp<=0){const end=finishBattle(battleId,socket.userId); b.players.forEach(uid=>io.to(userRoom(uid)).emit("battle:finished",end)); return;}
      b.turn=opponent; io.to(userRoom(opponent)).emit("battle:turn",{turn:opponent}); io.to(userRoom(socket.userId)).emit("battle:turn",{turn:opponent});
    });

    socket.on("battle:ping",()=>socket.emit("battle:pong",{ok:true,time:Date.now()}));
    socket.on("disconnect",()=>{if(online.get(socket.userId)===socket.id)online.delete(socket.userId);emitOnline();});
  });
  return io;
}
module.exports={setup};
