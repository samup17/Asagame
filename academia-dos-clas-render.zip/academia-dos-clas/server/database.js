const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");

const root = path.join(__dirname, "..");
const dbDir = path.join(root, "database");
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const dbPath = process.env.DATABASE_URL
  ? path.resolve(root, process.env.DATABASE_URL)
  : path.join(dbDir, "academia.db");

const db = new Database(dbPath);
db.pragma("foreign_keys = ON");
db.pragma("journal_mode = WAL");

const schema = fs.readFileSync(path.join(dbDir, "schema.sql"), "utf8");
db.exec(schema);

function seed() {
  const subjectCount = db.prepare("SELECT COUNT(*) c FROM subjects").get().c;
  if (!subjectCount) {
    const subjects = [
      ["Matemática","matematica"],["Português","portugues"],["Ciências","ciencias"],
      ["História","historia"],["Geografia","geografia"],["Inglês","ingles"],
      ["Física","fisica"],["Química","quimica"],["Biologia","biologia"],
      ["Filosofia","filosofia"],["Sociologia","sociologia"]
    ];
    const stmt = db.prepare("INSERT INTO subjects(name,slug) VALUES(?,?)");
    const tx = db.transaction(() => subjects.forEach(s => stmt.run(...s)));
    tx();
  }

  if (!db.prepare("SELECT COUNT(*) c FROM clans").get().c) {
    const clans = [
      ["Clã Fênix","🔥","#f97316","Coragem, persistência e renascimento."],
      ["Clã Trovão","⚡","#eab308","Velocidade mental e energia."],
      ["Clã Lua","🌙","#8b5cf6","Estratégia, calma e observação."],
      ["Clã Floresta","🌿","#22c55e","Cooperação, equilíbrio e crescimento."]
    ];
    const stmt = db.prepare("INSERT INTO clans(name,symbol,color,description) VALUES(?,?,?,?)");
    const tx = db.transaction(() => clans.forEach(c => stmt.run(...c)));
    tx();
  }

  if (!db.prepare("SELECT COUNT(*) c FROM classes").get().c) {
    const clans = db.prepare("SELECT id FROM clans ORDER BY id").all();
    [["701",clans[0].id,"Fundamental"],["702",clans[1].id,"Fundamental"],
     ["703",clans[2].id,"Fundamental"],["801",clans[3].id,"Fundamental"]]
      .forEach(c => db.prepare("INSERT INTO classes(name,clan_id,grade) VALUES(?,?,?)").run(...c));
  }

  const admin = db.prepare("SELECT id FROM users WHERE role='ADMIN' LIMIT 1").get();
  if (!admin) {
    const insertUser = db.prepare(`INSERT INTO users
      (name,nickname,access_code,role,coins) VALUES(?,?,?,?,?)`);
    insertUser.run("Administrador Demo","Admin","ADMIN-0001","ADMIN",5000);
    insertUser.run("Professor Demo","ProfDemo","PROF-0001","TEACHER",1000);
    const c701 = db.prepare("SELECT id FROM classes WHERE name='701'").get().id;
    const c702 = db.prepare("SELECT id FROM classes WHERE name='702'").get().id;
    insertUser.run("Aluno Demo 1","Aluno1","#701-4582","STUDENT",250);
    insertUser.run("Aluno Demo 2","Aluno2","#702-7714","STUDENT",250);
    db.prepare("UPDATE users SET class_id=? WHERE access_code='#701-4582'").run(c701);
    db.prepare("UPDATE users SET class_id=? WHERE access_code='#702-7714'").run(c702);
  }

  if (!db.prepare("SELECT COUNT(*) c FROM questions").get().c) {
    const math = db.prepare("SELECT id FROM subjects WHERE slug='matematica'").get().id;
    const port = db.prepare("SELECT id FROM subjects WHERE slug='portugues'").get().id;
    const q = db.prepare(`INSERT INTO questions
      (subject_id,topic,grade,difficulty,type,prompt,options_json,correct_answer,explanation,xp,coins,variant_key)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`);
    const demo = [
      [math,"Multiplicação","Fundamental","EASY","MCQ","Quanto é 7 × 8?",["54","56","64","48"],"56","Multiplicar 7 por 8 é somar 7 oito vezes: 56.",10,5,"mul"],
      [math,"Frações","Fundamental","MEDIUM","MCQ","Qual fração é equivalente a 1/2?",["2/4","2/3","3/5","4/6"],"2/4","Multiplicando numerador e denominador por 2, obtemos 2/4.",20,10,"frac"],
      [math,"Porcentagem","Fundamental","HARD","NUMBER","Quanto é 25% de 200?",[],"50","25% é um quarto. Um quarto de 200 é 50.",40,20,"pct"],
      [port,"Gramática","Fundamental","EASY","MCQ","Qual palavra é um verbo?",["azul","correr","casa","feliz"],"correr","Verbo indica ação ou estado; correr indica uma ação.",10,5,"verb"],
      [math,"Verdadeiro ou falso","Fundamental","EASY","TF","10 é maior que 7?",["Verdadeiro","Falso"],"Verdadeiro","10 é maior que 7.",10,5,"tf10"]
    ];
    const tx = db.transaction(() => demo.forEach(x => q.run(x[0],x[1],x[2],x[3],x[4],x[5],JSON.stringify(x[6]),x[7],x[8],x[9],x[10],x[11])));
    tx();
  }

  if (!db.prepare("SELECT COUNT(*) c FROM items").get().c) {
    const item = db.prepare("INSERT INTO items(name,type,rarity,description,attack,defense,crit,hp,price,icon) VALUES(?,?,?,?,?,?,?,?,?,?)");
    [
      ["Amuleto do Foco","ACCESSORY","COMMON","Pequeno bônus de concentração.",0,2,2,0,120,"✦"],
      ["Poção de Estudo","CONSUMABLE","COMMON","Recupera 20 HP.",0,0,0,20,80,"🧪"],
      ["Caderno Astral","ACCESSORY","RARE","Aumenta levemente a recompensa de XP.",0,1,4,0,300,"📘"]
    ].forEach(x=>item.run(...x));
  }

  if (!db.prepare("SELECT COUNT(*) c FROM fruits").get().c) {
    const fruit = db.prepare("INSERT INTO fruits(name,rarity,price,description,ability,bonus_json,icon) VALUES(?,?,?,?,?,?,?)");
    [
      ["Fruta do Vira-lata","COMMON",350,"Transforma a energia do mascote em resistência.","Latido de Guarda: +4 defesa.","{\"defense\":4}","🐕"],
      ["Fruta do Pato","UNCOMMON",600,"Uma fruta brincalhona que melhora a precisão.","Quack Tático: +5 precisão.","{\"accuracy\":5}","🦆"],
      ["Fruta do Gato","RARE",900,"Agilidade felina para momentos decisivos.","Salto Silencioso: +6 crítico.","{\"crit\":6}","🐈"],
      ["Fruta da Capivara","LEGENDARY",5000,"Relíquia raríssima do rio. Forte, mas equilibrada.","Calma do Rio: reduz o dano recebido uma vez por batalha.","{\"hp\":20,\"defense\":8,\"accuracy\":3,\"crit\":3}","🦫"],
      ["Fruta da Batata","EPIC",1400,"Uma fruta culinária estranhamente eficiente.","Casca Reforçada: +10 HP e +3 defesa.","{\"hp\":10,\"defense\":3}","🥔"]
    ].forEach(x=>fruit.run(...x));
  }

  if (!db.prepare("SELECT COUNT(*) c FROM weapons").get().c) {
    const w = db.prepare("INSERT INTO weapons(name,rarity,price,attack,defense,crit,description,icon) VALUES(?,?,?,?,?,?,?,?)");
    [
      ["Espada de Madeira","COMMON",100,4,1,0,"Confiável para começar.","🪵"],
      ["Lâmina Solar","RARE",800,10,2,3,"Brilha quando a resposta está correta.","☀️"],
      ["Espada do Trovão","EPIC",1600,16,1,5,"Canaliza energia em ataques precisos.","⚡"],
      ["Lâmina Lunar","RARE",1100,8,6,2,"Equilibra ataque e defesa.","🌙"],
      ["Espada do Guardião","LEGENDARY",3000,14,10,2,"Uma defesa que também sabe atacar.","🛡️"]
    ].forEach(x=>w.run(...x));
  }

  const starterWeapon = db.prepare("SELECT id FROM weapons WHERE name='Espada de Madeira'").get();
  const starterFruit = db.prepare("SELECT id FROM fruits WHERE name='Fruta do Vira-lata'").get();
  const students = db.prepare("SELECT id FROM users WHERE role='STUDENT'").all();
  if (starterWeapon && starterFruit) {
    for (const st of students) {
      db.prepare("INSERT OR IGNORE INTO inventory(user_id,item_kind,item_id,quantity,equipped) VALUES(?,?,?,?,?)").run(st.id,"WEAPON",starterWeapon.id,1,1);
      db.prepare("INSERT OR IGNORE INTO inventory(user_id,item_kind,item_id,quantity,equipped) VALUES(?,?,?,?,?)").run(st.id,"FRUIT",starterFruit.id,1,1);
    }
  }

  const inviteCount = db.prepare("SELECT COUNT(*) c FROM teacher_invites").get().c;
  if (!inviteCount) {
    const hash = bcrypt.hashSync("PROF-ACADEMIA-2026", 10);
    db.prepare("INSERT INTO teacher_invites(code_hash,label,max_uses) VALUES(?,?,?)").run(hash,"Código de professor demo",1000);
  }

  if (!db.prepare("SELECT COUNT(*) c FROM missions").get().c) {
    const m = db.prepare("INSERT INTO missions(name,description,goal_type,target,reward_xp,reward_coins) VALUES(?,?,?,?,?,?)");
    [
      ["Primeiro treino","Resolva 10 questões.","ANSWERS",10,50,80],
      ["Sequência de foco","Consiga 5 respostas corretas seguidas.","STREAK",5,70,120],
      ["Duelo acadêmico","Vença uma batalha.","WIN_BATTLE",1,100,150],
      ["Explorador do saber","Pratique em uma sessão.","SESSION",1,30,50]
    ].forEach(x=>m.run(...x));
  }
}
seed();

module.exports = db;
