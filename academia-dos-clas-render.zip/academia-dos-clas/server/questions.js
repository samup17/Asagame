const db = require("./database");

function pickQuestion(userId, subjectId, difficulty) {
  const user = db.prepare("SELECT class_id FROM users WHERE id=?").get(userId);
  const assigned = user?.class_id ? db.prepare(`SELECT q.id FROM teacher_question_choices tqc JOIN questions q ON q.id=tqc.question_id
    WHERE tqc.class_id=? AND tqc.active=1 ${subjectId?"AND q.subject_id=?":""} ${difficulty?"AND q.difficulty=?":""} ORDER BY RANDOM()`).all(...[user.class_id].concat(subjectId?[Number(subjectId)]:[]).concat(difficulty?[difficulty]:[])) : [];
  const assignedIds = assigned.map(x=>x.id);
  const recent = db.prepare(`SELECT question_id FROM answers WHERE user_id=? ORDER BY id DESC LIMIT 12`).all(userId).map(x=>x.question_id);
  let sql = `SELECT q.*, s.name subject_name FROM questions q JOIN subjects s ON s.id=q.subject_id WHERE 1=1`;
  const params = [];
  if (assignedIds.length) {
    sql += ` AND q.id IN (${assignedIds.map(()=>"?").join(",")})`; params.push(...assignedIds);
  } else if (subjectId) { sql += " AND q.subject_id=?"; params.push(Number(subjectId)); }
  if (difficulty) { sql += " AND q.difficulty=?"; params.push(difficulty); }
  if (recent.length) sql += ` AND q.id NOT IN (${recent.map(()=>"?").join(",")})`;
  params.push(...recent);
  sql += " ORDER BY RANDOM() LIMIT 1";
  let q = db.prepare(sql).get(...params);
  if (!q) {
    q = db.prepare(`SELECT q.*, s.name subject_name FROM questions q JOIN subjects s ON s.id=q.subject_id
      ${subjectId ? "WHERE q.subject_id=?" : ""} ORDER BY RANDOM() LIMIT 1`).get(...(subjectId?[Number(subjectId)]:[]));
  }
  if (!q) return null;
  q.options = JSON.parse(q.options_json || "[]");
  delete q.options_json; delete q.correct_answer;
  return q;
}

function pickQuestionForBattle(userId, subjectId, difficulty) { return pickQuestion(userId, subjectId, difficulty); }
function validateAnswer(questionId, answer) {
  const q = db.prepare("SELECT * FROM questions WHERE id=?").get(questionId);
  if (!q) return {exists:false, correct:false};
  const normalized = String(answer ?? "").trim().toLowerCase();
  const correct = normalized === String(q.correct_answer).trim().toLowerCase();
  return {exists:true,correct,q};
}
function createQuestion(data, userId) {
  const stmt = db.prepare(`INSERT INTO questions
    (subject_id,topic,grade,difficulty,type,prompt,options_json,correct_answer,explanation,xp,coins,variant_key,created_by)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  return stmt.run(
    Number(data.subject_id), String(data.topic), String(data.grade), String(data.difficulty),
    String(data.type), String(data.prompt), JSON.stringify(data.options || []), String(data.correct_answer),
    String(data.explanation || ""), Number(data.xp || 10), Number(data.coins || 5), data.variant_key || null, userId
  ).lastInsertRowid;
}
module.exports = {pickQuestion,pickQuestionForBattle,validateAnswer,createQuestion};
