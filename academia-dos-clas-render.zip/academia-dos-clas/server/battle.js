const db = require("./database");
const {addCoins,addXp,addClanPoints} = require("./economy");
const {publicUser} = require("./auth");

const active = new Map();

function createBattle(a,b) {
  const battle = db.prepare("INSERT INTO battles(mode,status) VALUES('PVP','ACTIVE')").run().lastInsertRowid;
  const ua = publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(a));
  const ub = publicUser(db.prepare("SELECT * FROM users WHERE id=?").get(b));
  const stmt = db.prepare("INSERT INTO battle_players(battle_id,user_id,slot,hp,max_hp) VALUES(?,?,?,?,?)");
  stmt.run(battle,a,1,ua.derived.max_hp,ua.derived.max_hp);
  stmt.run(battle,b,2,ub.derived.max_hp,ub.derived.max_hp);
  active.set(String(battle), {id:battle,players:[a,b],turn:a,answered:{},damage:[],guardUsed:{},specialUsed:{},action:"ATTACK",currentQuestion:null});
  return active.get(String(battle));
}
function getBattle(id) { return active.get(String(id)); }
function applyDamage(id,targetId,damage) {
  const b = getBattle(id);
  if (!b) return null;
  const row = db.prepare("SELECT hp FROM battle_players WHERE battle_id=? AND user_id=?").get(id,targetId);
  const hp = Math.max(0,row.hp - Math.max(0,Math.floor(damage)));
  db.prepare("UPDATE battle_players SET hp=? WHERE battle_id=? AND user_id=?").run(hp,id,targetId);
  return hp;
}
function finishBattle(id,winnerId) {
  const b = getBattle(id);
  if (!b) return;
  const loserId = b.players.find(x=>x!==winnerId);
  db.prepare("UPDATE battles SET status='FINISHED',winner_id=?,ended_at=CURRENT_TIMESTAMP WHERE id=?").run(winnerId,id);
  addCoins(winnerId,80,"Vitória em batalha");
  addXp(winnerId,60);
  addClanPoints(winnerId,25);
  const winMission=db.prepare("SELECT id,target FROM missions WHERE goal_type='WIN_BATTLE' LIMIT 1").get();
  if (winMission) db.prepare("INSERT OR IGNORE INTO user_missions(user_id,mission_id,progress,completed) VALUES(?,?,0,0)").run(winnerId,winMission.id);
  if (winMission) db.prepare("UPDATE user_missions SET progress=?,completed=1 WHERE user_id=? AND mission_id=?").run(winMission.target,winnerId,winMission.id);
  if (loserId) { addCoins(loserId,20,"Participação em batalha"); addXp(loserId,15); }
  active.delete(String(id));
  return {winnerId,loserId};
}
module.exports = {createBattle,getBattle,applyDamage,finishBattle,active};
