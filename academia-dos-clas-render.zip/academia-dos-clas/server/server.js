try { require("dotenv").config(); } catch (_) {}
const http = require("http");
const path = require("path");
const express = require("express");
const helmet = require("helmet");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const db = require("./database");
const {loginByCode,requireAuth,requireRole,refreshSessionUser,createStudent,createTeacher,generateAccessCode} = require("./auth");
const {pickQuestion,validateAnswer,createQuestion} = require("./questions");
const {addCoins,spendCoins,addXp,addClanPoints,ensureMissionRows,progressMission} = require("./economy");
const {stats} = require("./admin");
const {setup} = require("./socket");

const app = express();
app.set("trust proxy", 1);
const server = http.createServer(app);
const PORT = Number(process.env.PORT || 3000);
const publicDir = path.join(__dirname,"..","client");

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"200kb"}));
app.use(express.urlencoded({extended:false}));
const sessionMiddleware = session({
  store:new SQLiteStore({db:"sessions.db",dir:path.join(__dirname,"..","database")}),
  secret:process.env.SESSION_SECRET || "dev-only-change-me",
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:1000*60*60*12}
});
app.use(sessionMiddleware);

const signupAttempts = new Map();
function allowSignup(req) {
  const key = req.ip || "unknown"; const now=Date.now(); const recent=signupAttempts.get(key)||[];
  const kept=recent.filter(t=>now-t<60*60*1000); if(kept.length>=10) return false; kept.push(now); signupAttempts.set(key,kept); return true;
}

app.post("/api/auth/register",(req,res)=>{
  if(!allowSignup(req)) return res.status(429).json({error:"Muitas tentativas de cadastro. Tente novamente mais tarde."});
  try { const created=createStudent({name:req.body.name,nickname:req.body.nickname,classId:req.body.class_id}); req.session.userId=created.id; res.status(201).json({user:created.user,access_code:created.code}); }
  catch(e){res.status(400).json({error:e.message||"Não foi possível criar a conta."});}
});

app.post("/api/auth/register-teacher",(req,res)=>{
  try { const created=createTeacher({name:req.body.name,nickname:req.body.nickname,classId:req.body.class_id,inviteCode:req.body.invite_code}); req.session.userId=created.id; res.status(201).json({user:created.user,access_code:created.code}); }
  catch(e){res.status(400).json({error:e.message||"Não foi possível criar a conta de professor."});}
});

app.post("/api/auth/login",(req,res)=>{
  const code=String(req.body.code||"").trim();
  if (!code) return res.status(400).json({error:"Informe o código."});
  const user=loginByCode(code);
  if (!user) return res.status(401).json({error:"Código inválido."});
  req.session.userId=user.id;
  res.json({user});
});
app.post("/api/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/auth/me",(req,res)=>{
  if (!req.session.userId) return res.status(401).json({error:"Não autenticado."});
  res.json({user:refreshSessionUser(req)});
});

app.get("/api/health",(req,res)=>res.json({ok:true,service:"academia-dos-clas",time:new Date().toISOString()}));

app.get("/api/public/classes",(req,res)=>res.json(db.prepare(`SELECT cl.id,cl.name,cl.grade,c.name clan_name,c.symbol,c.color FROM classes cl JOIN clans c ON c.id=cl.clan_id ORDER BY cl.name`).all()));

app.get("/api/bootstrap",requireAuth,(req,res)=>{
  const user=refreshSessionUser(req);
  const subjects=db.prepare("SELECT * FROM subjects ORDER BY name").all();
  const clans=db.prepare("SELECT * FROM clans ORDER BY points DESC").all();
  const classes=db.prepare("SELECT cl.*,c.name clan_name,c.symbol,c.color FROM classes cl JOIN clans c ON c.id=cl.clan_id ORDER BY cl.name").all();
  res.json({user,subjects,clans,classes});
});

app.get("/api/question",requireAuth,(req,res)=>{
  const q=pickQuestion(req.session.userId,req.query.subjectId,req.query.difficulty);
  if (!q) return res.status(404).json({error:"Você já respondeu a maioria das perguntas disponíveis. Novas perguntas serão adicionadas em breve."});
  res.json(q);
});
app.post("/api/question/answer",requireAuth,(req,res)=>{
  const questionId=Number(req.body.questionId);
  const result=validateAnswer(questionId,req.body.answer);
  if (!result.exists) return res.status(404).json({error:"Pergunta não encontrada."});
  const userId=req.session.userId;
  const xp=result.correct?result.q.xp:0, coins=result.correct?result.q.coins:0;
  db.prepare(`INSERT INTO answers(user_id,question_id,answer,correct,response_ms,xp_gained,coins_gained)
    VALUES(?,?,?,?,?,?,?)`).run(userId,questionId,String(req.body.answer??""),result.correct?1:0,Number(req.body.responseMs||0),xp,coins);
  if (result.correct) {
    const level=addXp(userId,xp);
    addCoins(userId,coins,"Resposta correta");
    addClanPoints(userId,5);
    db.prepare("UPDATE users SET streak=streak+1 WHERE id=?").run(userId);
    progressMission(userId,"ANSWERS",1);
    const streakRow=db.prepare("SELECT streak FROM users WHERE id=?").get(userId);
    if(streakRow?.streak) progressMission(userId,"STREAK",streakRow.streak);
    res.json({correct:true,explanation:result.q.explanation,xp,coins,level});
  } else {
    db.prepare("UPDATE users SET streak=0 WHERE id=?").run(userId);
    res.json({correct:false,explanation:result.q.explanation,xp:0,coins:0});
  }
});

app.get("/api/profile",requireAuth,(req,res)=>{
  const user=refreshSessionUser(req);
  const progress=db.prepare(`SELECT s.name subject, COUNT(a.id) answers,
    ROUND(CASE WHEN COUNT(a.id)=0 THEN 0.0 ELSE AVG(a.correct)*100 END) accuracy
    FROM subjects s LEFT JOIN questions q ON q.subject_id=s.id LEFT JOIN answers a ON a.question_id=q.id AND a.user_id=?
    GROUP BY s.id ORDER BY s.name`).all(req.session.userId);
  res.json({user,progress});
});

app.get("/api/ranking",requireAuth,(req,res)=>{
  const rows=db.prepare(`SELECT u.nickname,u.level,u.xp,u.coins,c.name clan_name,c.symbol,
    COALESCE(SUM(CASE WHEN a.correct=1 THEN q.xp ELSE 0 END),0) points
    FROM users u LEFT JOIN classes cl ON cl.id=u.class_id LEFT JOIN clans c ON c.id=cl.clan_id
    LEFT JOIN answers a ON a.user_id=u.id LEFT JOIN questions q ON q.id=a.question_id
    WHERE u.role='STUDENT' GROUP BY u.id ORDER BY points DESC, u.level DESC, u.xp DESC LIMIT 100`).all();
  res.json(rows);
});

app.get("/api/clan",requireAuth,(req,res)=>{
  const user=refreshSessionUser(req);
  if (!user.clan) return res.json({clan:null,members:[]});
  const members=db.prepare(`SELECT nickname,level,xp FROM users WHERE class_id=? ORDER BY xp DESC`).all(user.class.id);
  res.json({clan:user.clan,members});
});

app.post("/api/inventory/equip",requireAuth,(req,res)=>{
  const uid=req.session.userId, kind=String(req.body.kind||""), id=Number(req.body.id);
  if(!["ITEM","FRUIT","WEAPON"].includes(kind) || !Number.isInteger(id)) return res.status(400).json({error:"Equipamento inválido."});
  const owned=db.prepare("SELECT id FROM inventory WHERE user_id=? AND item_kind=? AND item_id=? AND quantity>0").get(uid,kind,id);
  if(!owned) return res.status(400).json({error:"Você não possui este item."});
  db.prepare("UPDATE inventory SET equipped=0 WHERE user_id=? AND item_kind=?").run(uid,kind);
  db.prepare("UPDATE inventory SET equipped=1 WHERE user_id=? AND item_kind=? AND item_id=?").run(uid,kind,id);
  res.json({ok:true,user:refreshSessionUser(req)});
});

app.get("/api/inventory",requireAuth,(req,res)=>{
  const uid=req.session.userId;
  const inv=db.prepare("SELECT * FROM inventory WHERE user_id=?").all(uid);
  const items=inv.map(x=>{
    const table=x.item_kind==="ITEM"?"items":x.item_kind==="FRUIT"?"fruits":"weapons";
    return {...x,data:db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(x.item_id)};
  });
  res.json(items);
});

app.post("/api/shop/buy",requireAuth,(req,res)=>{
  const kind=String(req.body.kind||"");
  const id=Number(req.body.id);
  const table=kind==="ITEM"?"items":kind==="FRUIT"?"fruits":kind==="WEAPON"?"weapons":null;
  if (!table || !Number.isInteger(id)) return res.status(400).json({error:"Item inválido."});
  const row=db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(id);
  if (!row) return res.status(404).json({error:"Item não encontrado."});
  if (!spendCoins(req.session.userId,row.price,`Compra: ${row.name}`)) return res.status(400).json({error:"Moedas insuficientes."});
  db.prepare(`INSERT INTO inventory(user_id,item_kind,item_id,quantity) VALUES(?,?,?,1)
    ON CONFLICT(user_id,item_kind,item_id) DO UPDATE SET quantity=quantity+1`).run(req.session.userId,kind,id);
  res.json({ok:true,user:refreshSessionUser(req)});
});

app.get("/api/gacha/odds",requireAuth,(req,res)=>res.json({cost:250,odds:{COMMON:60,UNCOMMON:25,RARE:10,EPIC:4,LEGENDARY:1}}));
app.post("/api/gacha/draw",requireAuth,(req,res)=>{
  const cost=250; if(!spendCoins(req.session.userId,cost,"Sorteio de fruta")) return res.status(400).json({error:"Moedas insuficientes."});
  const roll=Math.random()*100; let rarity=roll<60?"COMMON":roll<85?"UNCOMMON":roll<95?"RARE":roll<99?"EPIC":"LEGENDARY";
  const pool=db.prepare("SELECT * FROM fruits WHERE rarity=?").all(rarity); if(!pool.length){addCoins(req.session.userId,cost,"Reembolso de sorteio sem prêmio");return res.status(500).json({error:"Não há frutas desta raridade cadastradas."});}
  const fruit=pool[Math.floor(Math.random()*pool.length)];
  db.prepare(`INSERT INTO inventory(user_id,item_kind,item_id,quantity) VALUES(?,?,?,1) ON CONFLICT(user_id,item_kind,item_id) DO UPDATE SET quantity=quantity+1`).run(req.session.userId,"FRUIT",fruit.id);
  res.json({ok:true,fruit,odds:{COMMON:60,UNCOMMON:25,RARE:10,EPIC:4,LEGENDARY:1},user:refreshSessionUser(req)});
});

app.get("/api/shop",requireAuth,(req,res)=>{
  res.json({
    items:db.prepare("SELECT * FROM items ORDER BY price").all(),
    fruits:db.prepare("SELECT * FROM fruits ORDER BY price").all(),
    weapons:db.prepare("SELECT * FROM weapons ORDER BY price").all()
  });
});

app.get("/api/missions",requireAuth,(req,res)=>{
  const uid=req.session.userId;
  ensureMissionRows(uid);
  const missions=db.prepare(`SELECT m.*,COALESCE(um.progress,0) progress,COALESCE(um.completed,0) completed,COALESCE(um.claimed,0) claimed
    FROM missions m LEFT JOIN user_missions um ON um.mission_id=m.id AND um.user_id=? ORDER BY m.id`).all(uid);
  res.json(missions);
});

app.post("/api/missions/:id/claim",requireAuth,(req,res)=>{
  const uid=req.session.userId, mid=Number(req.params.id);
  const m=db.prepare("SELECT * FROM missions WHERE id=?").get(mid);
  if (!m) return res.status(404).json({error:"Missão não encontrada."});
  const current=db.prepare("SELECT * FROM user_missions WHERE user_id=? AND mission_id=?").get(uid,mid);
  const progress=current?.progress||0;
  if (progress<m.target || current?.claimed) return res.status(400).json({error:"Missão ainda não está pronta."});
  db.prepare("UPDATE user_missions SET claimed=1,completed=1 WHERE user_id=? AND mission_id=?").run(uid,mid);
  addXp(uid,m.reward_xp); addCoins(uid,m.reward_coins,"Recompensa de missão");
  res.json({ok:true,user:refreshSessionUser(req)});
});

app.get("/api/teacher/questions",requireRole("TEACHER","ADMIN"),(req,res)=>{
  const qs=db.prepare(`SELECT q.*,s.name subject_name FROM questions q JOIN subjects s ON s.id=q.subject_id ORDER BY q.id DESC`).all();
  res.json(qs);
});
app.post("/api/teacher/questions",requireRole("TEACHER","ADMIN"),(req,res)=>{
  try { const id=createQuestion(req.body,req.session.userId); res.json({ok:true,id}); }
  catch(e){res.status(400).json({error:"Dados da pergunta inválidos."});}
});
app.delete("/api/teacher/questions/:id",requireRole("TEACHER","ADMIN"),(req,res)=>{
  db.prepare("DELETE FROM questions WHERE id=?").run(Number(req.params.id)); res.json({ok:true});
});
app.get("/api/teacher/assignments",requireRole("TEACHER","ADMIN"),(req,res)=>{
  const uid=req.session.userId; const rows=db.prepare(`SELECT tqc.*,cl.name class_name,q.prompt,s.name subject_name FROM teacher_question_choices tqc JOIN classes cl ON cl.id=tqc.class_id JOIN questions q ON q.id=tqc.question_id JOIN subjects s ON s.id=q.subject_id WHERE tqc.teacher_id=? ORDER BY tqc.created_at DESC`).all(uid); res.json(rows);
});
app.post("/api/teacher/assignments",requireRole("TEACHER","ADMIN"),(req,res)=>{
  const uid=req.session.userId, classId=Number(req.body.class_id), questionId=Number(req.body.question_id);
  if(!Number.isInteger(classId)||!Number.isInteger(questionId)) return res.status(400).json({error:"Turma ou pergunta inválida."});
  try { db.prepare("INSERT INTO teacher_question_choices(teacher_id,class_id,question_id,active) VALUES(?,?,?,1) ON CONFLICT(teacher_id,class_id,question_id) DO UPDATE SET active=1").run(uid,classId,questionId); res.json({ok:true}); } catch(e){res.status(400).json({error:"Não foi possível selecionar a pergunta."});}
});
app.delete("/api/teacher/assignments",requireRole("TEACHER","ADMIN"),(req,res)=>{ db.prepare("DELETE FROM teacher_question_choices WHERE teacher_id=? AND class_id=? AND question_id=?").run(req.session.userId,Number(req.body.class_id),Number(req.body.question_id)); res.json({ok:true}); });

app.get("/api/teacher/stats",requireRole("TEACHER","ADMIN"),(req,res)=>{
  const bySubject=db.prepare(`SELECT s.name,COUNT(a.id) answers,
    ROUND(CASE WHEN COUNT(a.id)=0 THEN 0 ELSE AVG(a.correct)*100 END) accuracy
    FROM subjects s LEFT JOIN questions q ON q.subject_id=s.id LEFT JOIN answers a ON a.question_id=q.id
    GROUP BY s.id ORDER BY s.name`).all();
  res.json({global:stats(),bySubject});
});

app.post("/api/admin/teacher-invites",requireRole("ADMIN"),(req,res)=>{
  const code=String(req.body.code||generateAccessCode()); const max=Math.max(1,Math.min(10000,Number(req.body.max_uses)||1));
  const bcrypt=require("bcryptjs"); const hash=bcrypt.hashSync(code,10);
  const id=db.prepare("INSERT INTO teacher_invites(code_hash,label,max_uses) VALUES(?,?,?)").run(hash,String(req.body.label||"Convite"),max).lastInsertRowid;
  res.json({ok:true,id,code});
});
app.get("/api/admin/teacher-invites",requireRole("ADMIN"),(req,res)=>res.json(db.prepare("SELECT id,label,max_uses,uses,active,created_at FROM teacher_invites ORDER BY id DESC").all()));
app.post("/api/admin/users",requireRole("ADMIN"),(req,res)=>{
  const {name,nickname,access_code,role,class_id}=req.body;
  if(!name||!nickname||!access_code||!["STUDENT","TEACHER","ADMIN"].includes(role)) return res.status(400).json({error:"Campos inválidos."});
  try { const id=db.prepare("INSERT INTO users(name,nickname,access_code,role,class_id) VALUES(?,?,?,?,?)").run(String(name),String(nickname),String(access_code),role,class_id?Number(class_id):null).lastInsertRowid; res.json({ok:true,id}); }
  catch(e){res.status(400).json({error:"Código já existe ou dados inválidos."});}
});
app.delete("/api/admin/users/:id",requireRole("ADMIN"),(req,res)=>{
  const id=Number(req.params.id); if(id===req.session.userId) return res.status(400).json({error:"Você não pode remover sua própria conta."});
  db.prepare("DELETE FROM users WHERE id=?").run(id); res.json({ok:true});
});

app.get("/api/admin/overview",requireRole("ADMIN"),(req,res)=>{
  res.json({
    stats:stats(),
    users:db.prepare("SELECT id,name,nickname,role,access_code,level,xp,coins FROM users ORDER BY id DESC").all(),
    classes:db.prepare(`SELECT cl.*,c.name clan_name FROM classes cl JOIN clans c ON c.id=cl.clan_id ORDER BY cl.name`).all(),
    clans:db.prepare("SELECT * FROM clans ORDER BY name").all()
  });
});
app.post("/api/admin/users",requireRole("ADMIN"),(req,res)=>{
  const {name,nickname,access_code,role,class_id}=req.body;
  if (!name||!nickname||!access_code||!["STUDENT","TEACHER","ADMIN"].includes(role)) return res.status(400).json({error:"Campos inválidos."});
  try {
    const id=db.prepare("INSERT INTO users(name,nickname,access_code,role,class_id) VALUES(?,?,?,?,?)")
      .run(String(name),String(nickname),String(access_code),role,class_id?Number(class_id):null).lastInsertRowid;
    res.json({ok:true,id});
  } catch(e){res.status(400).json({error:"Código já existe ou dados inválidos."});}
});
app.post("/api/admin/classes",requireRole("ADMIN"),(req,res)=>{
  try {
    const id=db.prepare("INSERT INTO classes(name,clan_id,grade) VALUES(?,?,?)").run(String(req.body.name),Number(req.body.clan_id),String(req.body.grade||"Fundamental")).lastInsertRowid;
    res.json({ok:true,id});
  } catch(e){res.status(400).json({error:"Turma inválida."});}
});
app.post("/api/admin/clans",requireRole("ADMIN"),(req,res)=>{
  const id=db.prepare("INSERT INTO clans(name,symbol,color,description) VALUES(?,?,?,?)")
    .run(String(req.body.name),String(req.body.symbol||"✦"),String(req.body.color||"#6d5dfc"),String(req.body.description||"")).lastInsertRowid;
  res.json({ok:true,id});
});

app.use(express.static(publicDir));
app.use((req,res)=>res.sendFile(path.join(publicDir,"index.html")));

setup(server,sessionMiddleware);

server.listen(PORT,"0.0.0.0",()=>console.log(`Academia dos Clãs em http://0.0.0.0:${PORT}`));
